# PROGRAM MONITORING ERROR

setpoint = 50

def hitung_error(output):

    error = abs(setpoint - output)

    return error

def tentukan_status(error):

    if error <= 2:

        return "STABIL"

    elif error <= 5:

        return "WARNING"

    else:

        return "TIDAK STABIL"

def hitung_jumlah_status(data_output, status_dicari):

    jumlah = 0

    for output in data_output:

        error = hitung_error(output)

        status = tentukan_status(error)

        if status == status_dicari:

            jumlah += 1

    return jumlah

def hitung_rata_rata_error(data_output):

    total = 0

    for output in data_output:

        total += hitung_error(output)

    rata_rata = total / len(data_output)

    return rata_rata
def cari_error_terbesar(data_output):

    daftar_error = []

    for output in data_output:
        daftar_error.append(hitung_error(output))

    return max(daftar_error)

def cari_error_terkecil(data_output):
    daftar_error = []

    for output in data_output:

        daftar_error.append(hitung_error(output))

    return min(daftar_error)

def uji_status(error):

    status = tentukan_status(error)

    return status

data_output = [ 
    50, 49, 47, 45, 43,
    52, 54, 57, 51, 48,
    46, 44, 53, 55, 42,
    48, 50, 53, 45, 56
   ]



print("MONITORING ERROR")
print("Setpoint:", setpoint)
print("Jumlah data:", len(data_output))

print("\nPERHITUNGAN ERROR")

for output in data_output:
    error = hitung_error(output)
    print("Output:", output, "| Error:", error)

print("\nKLASIFIKASI STATUS")

for output in data_output:
    error = hitung_error(output)
    status = tentukan_status(error)

    print("Output:", output, "| Error:", error, "| Status:", status)

print("\nRINGKASAN MONITORING")

print("Total data:", len(data_output))
print("Jumlah STABIL:", hitung_jumlah_status(data_output, "STABIL"))
print("Jumlah WARNING:", hitung_jumlah_status(data_output, "WARNING"))
print("Jumlah TIDAK STABIL:", hitung_jumlah_status(data_output, "TIDAK STABIL"))

print("Rata-rata error:", hitung_rata_rata_error(data_output))
print("Error terbesar:", cari_error_terbesar(data_output))
print("Error terkecil:", cari_error_terkecil(data_output))

data_uji = [

    (51, "STABIL"),

    (52, "STABIL"),

    (53, "WARNING"),

    (54, "WARNING"),

    (55, "WARNING"),

    (56, "TIDAK STABIL"),

    (50, "STABIL"),

    (58, "TIDAK STABIL")

]

for output, harapan in data_uji:

    error = hitung_error(output)

    hasil = uji_status(error)

    if hasil == harapan:

        keterangan = "PASS"

    else:

        keterangan = "FAIL"

    print("Output:", output,

          "| Error:", error,

          "| Harapan:", harapan,

          "| Hasil:", hasil,

          "|", keterangan)